#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
                          
int main() {
    	float r;
	const float PI=3.14;
	scanf ("%f", &r);
	if (r<0) 
	{
	printf ("None");
	return 0;}
	else {
	printf ("%.3f\n", 2*PI*r);
	printf ("%.3f\n", PI*r*r);}
}