#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    float r;
    const float pi=3.14;
    scanf ("%f",&r);
    if (r<0){
        printf("None");
        return 0; }
    else {
       printf ("%.3f\n",r*pi*2);
        printf ("%.3f",r*r*pi);
    }
    return 0;
}