#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
   long a,b;
scanf("%ld%ld", &a,&b);
if(a==b)
{printf("None");
return 0;
}
if(a>b)
{printf("%ld",a);
}
else{printf("%ld",b);
}
    return 0;
}