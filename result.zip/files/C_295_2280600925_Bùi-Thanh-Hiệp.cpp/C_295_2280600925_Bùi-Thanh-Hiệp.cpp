#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    long a,b,c;
	 scanf ("%ld%ld%ld", &a, &b, &c);
	 if (a==b&&a==c){
	 	printf ("None");
	 	return 0;
	 }
	  if (a>b&&a>c){
	 printf ("%ld", a);	
	 }else if(b>c) {
	 	printf ("%ld", b);
} else
{
printf ("%ld", c);
}   
    return 0;
}