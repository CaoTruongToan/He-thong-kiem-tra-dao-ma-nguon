#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    const float PI = 3.14;
	float r;
	scanf("%f", &r);
	if(r<0){
		printf("None");
	}else{
	printf("%.3f \n", 2*PI*r);
	printf("%.3f", PI*r*r);
}    
    return 0;
}