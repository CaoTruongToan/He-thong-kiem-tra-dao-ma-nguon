#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    	float r;
	scanf("%f", &r);
	if(r<=0) {
	printf("None");
	return 0;
	}else{
		#define PI 3.14
		printf("%.3f\n", 2*PI*r);
		printf("%.3f\n", PI*r*r);
			}
    return 0;
}