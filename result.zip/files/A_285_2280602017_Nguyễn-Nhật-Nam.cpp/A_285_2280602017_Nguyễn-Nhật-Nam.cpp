#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#define PI 3.14
int main() {float r;
	scanf("%f", &r);
	if (r<0) {
	printf("None");
	return 0;
	}
	else{
	printf("%.3f\n",2*PI*r);
	printf("%.3f",PI*r*r);
}
    /* Enter your code here. Read input from STDIN (scanf). Print output to STDOUT (printf) */    
    return 0;
}