#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() 
{
    long a,b,c,max;
	scanf ("%ld%ld%ld",&a,&b,&c);
	max=a;
	if (max==b && max==c){
	printf("None");
	return 0;}
 	else{
		if (max<b) 
		max=b;
		if (max<c)
		max=c;
		printf ("%ld",max);
		
		
			
			
				}
	
}
    
