#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    	float r;
	const float PI= 3.14;
	scanf("%f", &r);
	if(r<0)
	{
		printf("None");
		return 0;
	}else {
		printf("%.3f\n",2*PI*r);
		printf("%.3f",(float)PI*r*r);
	}   
    return 0;
}