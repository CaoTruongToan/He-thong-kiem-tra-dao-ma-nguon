#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    long a,b,c;
	 scanf ("%ld%ld%ld", &a, &b, &c);
	 if (a==b&&a==c||a==c||a==b){
	 	printf ("-1");
	 	return 0;
	 }
	  if (a>b&&b>c&&a>c){
	 printf ("%ld", b);	
	 }else if(a>c&&b>c) {
	 	printf ("%ld", a);
} else
{
printf ("%ld", c);
}    
    return 0;
}