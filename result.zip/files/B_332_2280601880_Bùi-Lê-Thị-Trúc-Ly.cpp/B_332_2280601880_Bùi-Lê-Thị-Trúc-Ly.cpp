#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
                            
int main() {
   	long a,b;
	scanf ("%ld%ld", &a,&b);
    long MAX ;
	
	if (a==b)
	{
		printf ("None");
		return 0;
	}
	if (a>b)
	    {
		MAX=a;
		printf ("%ld", MAX);
		return 0;}
	else MAX=b;
		printf ("%ld",MAX);
	
}