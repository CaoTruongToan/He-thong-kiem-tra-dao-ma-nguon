#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() 
{
    	long a,b,c;
	scanf ("%ld%ld%ld",&a,&b,&c);
	if (a==b && a==c || a==b || a==c){
		printf("-1");}
		else {
			if (a<b&&b<c||c<b&&b<a){
			
			printf ("%ld",b);}
			else
			if (b<a&&a<c||c<a&&a<b)
			{
			printf ("%ld",a);}
			else
			if(b<c&&c<a||a<c&&c<b){
			
			printf ("%ld",c);}
		}
}
    