#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    long a,b,c;
	scanf("%ld%ld%ld", &a, &b, &c);
	
	if(a==b||a==c||b==c){
		printf("-1");
		return 0;
		
	}
	if(a>b&a>c&b>c){
	printf("%ld",b);
	}else if(a>b&a>c&c>b){
		printf("%ld"", c");
		}else if(c<a){
			printf("%ld",a);
		}
	else{	
	printf("%ld",c);
	}
	    
    return 0;
}